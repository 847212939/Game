
1.Release:
{
    2.include:
        C:\code\MyGame\Res\libevent\include;C:\code\MyGame\Res\mysql\include;C:\code\MyGame\Res\openssl\include;C:\code\MyGame\Res\tolua\include;C:\code\MyGame\Res\zlib2\include;
    3.includeLib:
        C:\code\MyGame\Res\libevent\lib;C:\code\MyGame\Res\mysql\lib;C:\code\MyGame\Res\openssl\lib;C:\code\MyGame\Res\tolua\libR;C:\code\MyGame\Res\zlib2\lib;
    4.lib:
        libevent.lib;libevent_core.lib;libevent_extras.lib;libevent_openssl.lib;ws2_32.lib;libmysql.lib;zlib.lib;Lua.lib;toLua.lib;
}

1.Debug:
{
    2.include:
        C:\code\MyGame\Res\libevent\include;C:\code\MyGame\Res\mysql\include;C:\code\MyGame\Res\openssl\include;C:\code\MyGame\Res\tolua\include;C:\code\MyGame\Res\zlib2\include;
    3.includeLib:
        C:\code\MyGame\Res\libevent\lib;C:\code\MyGame\Res\mysql\lib;C:\code\MyGame\Res\openssl\lib;C:\code\MyGame\Res\tolua\libD;C:\code\MyGame\Res\zlib2\lib;
    4.lib:
        libevent.lib;libevent_core.lib;libevent_extras.lib;libevent_openssl.lib;ws2_32.lib;libmysql.lib;zlib.lib;Lua.lib;toLua.lib;
}




//[DllImport("..\\..\\..\\..\\..\\x64\\Debug\\Cxxdll.dll",CallingConvention = CallingConvention.Cdecl)]
